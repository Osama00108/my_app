import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'home_page.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Page'),
        backgroundColor: Colors.blue.shade600, // لون سماوي للـ AppBar
      ),
      drawer: const AppDrawer(),
      body: Container(
        color: Colors.white, // خلفية بيضاء نظيفة
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // العنوان الرئيسي
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Icon(
                        Icons.contact_mail,
                        color: Colors.blue.shade600,
                        size: 60,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'تواصل معي 📞',
                        style: TextStyle(
                          fontSize: 28,
                          color: Colors.blue.shade800,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              // معلومات الاتصال
              Expanded(
                child: ListView(
                  children: [
                    // رقم الهاتف
                    Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ListTile(
                        leading: Icon(Icons.phone, color: Colors.blue.shade600),
                        title: const Text(
                          '01096968741',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: const Text('اضغط للاتصال'),
                        onTap: () => _launchUrl('tel:01096968741'),
                      ),
                    ),
                    const Divider(height: 10),
                    // البريد الإلكتروني
                    Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ListTile(
                        leading: Icon(Icons.email, color: Colors.blue.shade600),
                        title: const Text(
                          'osamanagy@gmail.com',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: const Text('اضغط لإرسال بريد إلكتروني'),
                        onTap: () => _launchUrl('mailto:osamanagy@gmail.com'),
                      ),
                    ),
                    const Divider(height: 10),
                    // LinkedIn
                    Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ListTile(
                        leading: Icon(Icons.link, color: Colors.blue.shade600),
                        title: const Text(
                          'linkedin.com/in/osama-nagy-a9b0a8313',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                        subtitle: const Text('اضغط لزيارة الملف الشخصي'),
                        onTap: () => _launchUrl(
                          'https://www.linkedin.com/in/osama-nagy-a9b0a8313?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // زر إرسال رسالة
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => _launchUrl('mailto:osamanagy@gmail.com'),
                  icon: const Icon(Icons.send),
                  label: const Text('إرسال رسالة'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade600,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
