import 'package:flutter/material.dart';
import 'home_page.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About Page'),
        backgroundColor: const Color(0xFF5A4FCF), // لون بنفسجي للـ AppBar
      ),
      drawer: const AppDrawer(),
      body: Container(
        color: Colors.white, // خلفية بيضاء نظيفة
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // العنوان والأيقونة
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Icon(
                        Icons.person_outline,
                        color: const Color(0xFF5A4FCF),
                        size: 80,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'About Osama Mohamed Nagy',
                        style: TextStyle(
                          fontSize: 24,
                          color: const Color(0xFF333333),
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              // النص التعريفي
              Expanded(
                child: Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      'I am Osama Mohamed Nagy, a passionate Flutter developer who enjoys creating modern, elegant, and user-friendly mobile applications. '
                      'This app is a simple example showing navigation, animation, and clean UI design using Flutter.',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black54,
                        height: 1.5,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              // زر الانتقال لصفحة التواصل
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.pushNamed(context, '/contact'),
                  icon: const Icon(Icons.contact_page_outlined),
                  label: const Text('Go to Contact Page'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF5A4FCF),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
